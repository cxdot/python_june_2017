# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.apps import AppConfig


class TimeDisplayAssingmentConfig(AppConfig):
    name = 'time_display_assingment'
