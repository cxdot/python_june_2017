from django.shortcuts import render, redirect
import random
from datetime import datetime

def index(request):
    #Default 'gold' to 0
    if 'gold' not in request.session:
        request.session['gold'] = 0
    #Default 'activites' to []
    if 'activities' not in request.session:
        request.session['activities'] = []

    context = {
        'activities': request.session['activities'],
        'gold': request.session['gold']
    }

    return render(request, 'ninja_gold_app/index.html', context)

def reset(request):
    request.session.flush()

    return redirect('/')

def process_money(request, building):
    print "Inside the process_money method."
    time = datetime.now().strftime("%Y/%m/%d %I:%M %p")

    #Determine Gold
    if building == 'farm':
        gold = random.randint(10, 20)
    elif building == 'cave':
        gold = random.randint(5, 10)
    elif building == 'house':
        gold = random.randint(2, 5)
    elif building == 'casino':
        gold = random.randint(-50, 50)
    else:
        'what are you doing with your life'

    request.session['gold'] += gold

    #Build activity
    if gold > 0:    #Earned Gold
        message = "Earned {} golds from the {}! ({})".format(gold, building, time)
        color = 'green'
    elif gold < 0:  #Lost Gold
        message = "Entered a {} and lost {} golds... Ouch... ({})".format(building, gold, time)
        color = 'red'
    else:           #Earned/Lost NOTHING
        message = "Hooray! You've wasted your time but winning and losing NOTHING!"
        color = 'black'

    activity = {'message': message, 'color': color}

    request.session['activities'].insert(0, activity)

    return redirect('/')
