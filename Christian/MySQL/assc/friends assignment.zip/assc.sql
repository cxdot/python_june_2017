select * from associates
